﻿<#
.SYNOPSIS
Script principal de los 4 módulos: VirusTotalHashCheck, LoginLogs, Recursos y RevealHiddenFiles.

.DESCRIPTION
Este script maneja los 4 módulos importados al script para revisar hashes mediante una API, listado de archivos ocultos, revisión de uso de recursos del sistema y logs de inicios de sesión.

.NOTES
Este es el script principal de los 4 módulos VirusTotalHashCheck, LoginLogs, Resources y RevealHiddenFiles. A pesar de eso, es posible utilizar los módulos individualmente mediante los parámetros especificados dentro de la ayuda
de estos scripts. Cada módulo tiene su set de parámetros de entrada, por lo que en caso de existir duda acerca de cómo utilizarlos individualmente, se puede revisar la documentación de estos módulos individualmente.

#>

Set-StrictMode -Version Latest

Import-Module -Name RevealHiddenFiles, LoginLogs, Resources, VirusTotalCheck   

function Open-Menu {

    $salida = $False 
    # Inicio de ciclo del menú
    while ($salida -eq $False) {

        $opcion = Read-Host -Prompt "¿A cuál información quiere acceder?
        [1] Revisión de hashes y consulta de API 'VirusTotal'.
        [2] Listado de archivos ocultos en una carpeta determinada.
        [3] Revisión de uso de recursos del sistema.
        [4] Logs de inicios de sesión y cambios de contraseña.
        [5] Salir"

        switch ($opcion) {
            1 {
                try {
                    Write-Host "Entrando a módulo de revisión de Hashes..." -ForegroundColor Green
                    Invoke-VirusTotalCheck          
                } catch {
                    Write-Host "Error al entrar al módulo de revisión de Hashes: $($_.Exception.Message)" -ForegroundColor Red
                }
                break
            }
            2 {
                try {
                    Write-Host "Entrando a módulo de listado de archivos ocultos..." -ForegroundColor Green
                    Get-Hidden      
                } catch {
                    Write-Host "Error al entrar al módulo de listado de archivos ocultos: $($_.Exception.Message)" -ForegroundColor Red 
                }
                break
            }
            3 {
                try {
                    $salida_mod3 = $False
                    while ($salida_mod3 -eq $False) {
                        Write-Host "Entrando a módulo de uso de recursos del sistema" -ForegroundColor Green
                        $opcion_mod3 = Read-Host -Prompt "¿Qué desea revisar?
                        [1] Información de la memoria
                        [2] Información del disco
                        [3] Información del CPU
                        [4] Información de la red
                        [5] Salir"

                        switch ($opcion_mod3) {
                            1 {
                                try {
                                    Get-InfoMemory
                                } catch {
                                    Write-Host "Error al llamar la función Get-InfoMemory: $($_.Exception.Message)" -ForegroundColor Red
                                }
                                break
                            }
                            2 {
                                try {
                                    Get-InfoDisk
                                } catch {
                                    Write-Host "Error al llamar la función Get-InfoDisk: $($_.Exception.Message)" -ForegroundColor Red
                                }
                                break
                            }
                            3 {
                                try {
                                    Get-InfoCPU
                                } catch {
                                    Write-Host "Error al llamar la función Get-InfoCPU: $($_.Exception.Message)" -ForegroundColor Red
                                }
                                break
                            }
                            4 {
                                try {
                                    Get-InfoNet
                                } catch {
                                    Write-Host "Error al llamar la función Get-InfoNet: $($_.Exception.Message)" -ForegroundColor Red
                                }
                                break
                            }
                            5 { 
                                $salida_mod3 = $True
                                Write-Host "Saliendo del módulo de recursos del sistema..." -ForegroundColor DarkMagenta
                                break
                            }
                            default {
                                Write-Host "Opción inválida" -ForegroundColor Red
                            }
                        }
                    }
                } catch {
                    Write-Host "Error al entrar al módulo de revisión de recursos del sistema: $($_.Exception.Message)" -ForegroundColor Red
                }
                break
            }
            4 {
                try {
                    Get-LogInChanges
                } catch {
                    Write-Host "Error al entrar al módulo de logs de inicios de sesión: $($_.Exception.Message)" -ForegroundColor Red
                }
                break
            }
            5 {
                $salida = $True
                Write-Host "Saliendo del script..." -ForegroundColor DarkMagenta
                break
            }
            default {
                Write-Host "Opción inválida" -ForegroundColor Red
                break
            }
        }
    }
}

Open-Menu